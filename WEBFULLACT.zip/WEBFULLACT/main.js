/* Stride & Bloom - main.js */

var PRODUCTS = [
  {n:'Rose Stiletto',       c:'heels',    p:1899, o:0,    img:'img/stilleto.jpg',t:'Bestseller'},
  {n:'Midnight Block Heel', c:'heels',    p:1599, o:1999, img:'img/black.jpg', t:'Sale'},
  {n:'Ballet Blush',        c:'flats',    p:999,  o:0,    img:'img/dollsj.jpg',t:'New'},
  {n:'Gold Strap Flat',     c:'flats',    p:1099, o:1399, img:'img/hierhgieo.jpg',     t:'Sale'},
  {n:'Summer Breeze',       c:'sandals',  p:849,  o:0,    img:'img/i.jpg',t:''},
  {n:'Beach Day Slide',     c:'sandals',  p:699,  o:899,  img:'img/j.jpg',     t:'Sale'},
  {n:'Cloud Runner',        c:'sneakers', p:1799, o:0,    img:'img/sneakers.jpg',        t:'New'},
  {n:'Daily White',         c:'sneakers', p:1499, o:0,    img:'img/e.jpg',         t:'Bestseller'}
];

var REVIEWS = [
  {name:'Jenny R.', product:'Rose Stiletto', stars:5, date:'Sep 2026', text:'So comfortable I wore them all night at my cousin\u2019s wedding. The fit is true to size.'},
  {name:'Carla M.', product:'Ballet Blush',  stars:5, date:'Oct 2026', text:'Beautiful color and super fast delivery. I\u2019m ordering another pair.'},
  {name:'Grace T.', product:'Daily White',   stars:4, date:'Oct 2026', text:'Light and cute, goes with everything. Took one day to break in, now my daily work shoes.'}
];

var cart = 0;

function renderProducts(filter){
  var html = '';
  PRODUCTS.forEach(function(product){
    if (filter !== 'all' && product.c !== filter) return;
    html += '<div class="card" data-category="' + product.c + '">' +
      '<div class="pic">' +
      (product.t ? '<span class="tag">' + product.t + '</span>' : '') +
      '<img src="' + product.img + '" alt="' + product.n + '">' +
      '</div><div class="info"><h4>' + product.n + '</h4>' +
      '<div class="row"><span class="price">\u20B1' + product.p.toLocaleString() +
      (product.o ? ' <s>\u20B1' + product.o.toLocaleString() + '</s>' : '') +
      '</span><button class="add" aria-label="Add ' + product.n + ' to cart">+</button>' +
      '</div></div></div>';
  });
  document.getElementById('products').innerHTML = html;
}

renderProducts('all');

document.getElementById('tabs').addEventListener('click', function(e){
  if (e.target.tagName !== 'BUTTON') return;
  document.querySelectorAll('#tabs button').forEach(function(b){ b.classList.remove('on'); });
  e.target.classList.add('on');
  renderProducts(e.target.dataset.f);
});

document.getElementById('products').addEventListener('click', function(e){
  if (!e.target.classList.contains('add')) return;
  cart++;
  document.getElementById('cartCount').textContent = cart;
  var b = e.target;
  b.textContent = '\u2713';
  setTimeout(function(){ b.textContent = '+'; }, 900);
});

function stars(n){ return '\u2605'.repeat(n) + '\u2606'.repeat(5 - n); }

var total = REVIEWS.reduce(function(a, r){ return a + r.stars; }, 0);
var averageScore = (total / REVIEWS.length).toFixed(1);
document.getElementById('avgScore').textContent = averageScore;
document.getElementById('avg').textContent =
  'out of 5 \u00B7 ' + REVIEWS.length + ' verified reviews';

document.getElementById('reviewList').innerHTML = REVIEWS.map(function(r, index){
  var initials = r.name.replace(/[^A-Za-z]/g, '').slice(0, 2).toUpperCase();
  return '<article class="review review-' + (index + 1) + '">' +
    '<span class="review-mark" aria-hidden="true">\u201C</span>' +
    '<div class="review-top"><div class="rstars" aria-label="' + r.stars + ' out of 5 stars">' + stars(r.stars) + '</div><span class="review-number">0' + (index + 1) + '</span></div>' +
    '<p>' + r.text + '</p>' +
    '<div class="who"><span class="review-avatar">' + initials + '</span><div><b>' + r.name + '</b><span>Verified buyer \u00B7 ' + r.product + '<small>' + r.date + '</small></span></div></div>' +
  '</article>';
}).join('');

document.getElementById('contactForm').addEventListener('submit', function(e){
  e.preventDefault();
  alert('Thanks! We will get back to you soon.');
  this.reset();
});
